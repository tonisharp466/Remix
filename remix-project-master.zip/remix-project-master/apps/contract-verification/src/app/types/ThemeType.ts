export type ThemeType = 'dark' | 'light'
