export const DEFAULT_TOML_CONFIG = `[package]
name = "test"
authors = [""]
compiler_version = ">=0.18.0"
type = "bin"

[dependencies]
`