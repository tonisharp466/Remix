import React from 'react'

const LogoPage: React.FC = () => {
  return (
    <div>
      <div>
        <img className="w-100" src="https://remix.ethereum.org/assets/img/remixLogo.webp" />
      </div>
    </div>
  )
}

export default LogoPage
